import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.lang.String.join;

public class MovieAnalyzer {
    private Stream<Movie> AllMovie;private List<Movie> Movielist;
    public static class Movie  {
        private int Released_Year;
        private String Poster_Link;
        private	String Series_Title;
        private String Certificate;
        private String Runtime;
        private String Genre;
        private float IMDB_Rating;
        private String Overview;
        private int Meta_score;
        private String Director;

        private String Star1;private String	Star2;private String Star3;private String Star4;
        private int No_of_Votes;
        private int Gross;

        public Movie(int Year,String Link,String Title, String certificate,
                                  String runtime, String genre, float  Rating, String overview	, int  score,
                                  String director, String star1,String	star2,String star3,String star4, int  Votes,
                                  int gross){
            this.Released_Year=Year;
            this.Poster_Link=Link;
            this.Director=director;
            this.Series_Title=Title;
            this.Certificate=certificate;
            this.Runtime=runtime;
            this.Genre=genre;
            this.IMDB_Rating=Rating;
            this.Overview=overview;
            this.Meta_score=score;
            this.Star1=star1;this.Star2=star2;this.Star3=star3;this.Star4=star4;
            this.No_of_Votes=Votes;this.Gross=gross;
        }
        public Movie(String Title,
                     String runtime, String overview	){
            this.Series_Title=Title;
            this.Runtime=runtime;
            this.Overview=overview;
        }

        public Movie(){

        }

        public int getReleased_Year() {
            return Released_Year;
        }

        public void setReleased_Year(int released_Year) {
            Released_Year = released_Year;
        }

        public String getPoster_Link() {
            return Poster_Link;
        }

        public void setPoster_Link(String poster_Link) {
            Poster_Link = poster_Link;
        }

        public String getSeries_Title() {
            return Series_Title;
        }

        public void setSeries_Title(String series_Title) {
            Series_Title = series_Title;
        }

        public String getCertificate() {
            return Certificate;
        }

        public void setCertificate(String certificate) {
            Certificate = certificate;
        }

        public String getRuntime() {
            return Runtime;
        }

        public void setRuntime(String runtime) {
            Runtime = runtime;
        }

        public String getGenre() {
            return Genre;
        }

        public void setGenre(String genre) {
            Genre = genre;
        }

        public double getIMDB_Rating() {
            return IMDB_Rating;
        }

        public void setIMDB_Rating(float IMDB_Rating) {
            this.IMDB_Rating = IMDB_Rating;
        }

        public String getOverview() {
            return Overview;
        }

        public void setOverview(String overview) {
            Overview = overview;
        }

        public int getMeta_score() {
            return Meta_score;
        }

        public void setMeta_score(int meta_score) {
            Meta_score = meta_score;
        }

        public String getDirector() {
            return Director;
        }

        public void setDirector(String director) {
            Director = director;
        }

        public String getStar1() {
            return Star1;
        }

        public void setStar1(String star1) {
            Star1 = star1;
        }

        public String getStar2() {
            return Star2;
        }

        public void setStar2(String star2) {
            Star2 = star2;
        }

        public String getStar3() {
            return Star3;
        }

        public void setStar3(String star3) {
            Star3 = star3;
        }

        public String getStar4() {
            return Star4;
        }

        public void setStar4(String star4) {
            Star4 = star4;
        }

        public int getNo_of_Votes() {
            return No_of_Votes;
        }

        public void setNo_of_Votes(int no_of_Votes) {
            No_of_Votes = no_of_Votes;
        }

        public int getGross() {
            return Gross;
        }

        public void setGross(int gross) {
            Gross = gross;
        }
    }
     public static String trimBothEnds(String srcStr, String splitter) {
        String regex = "^" + splitter + "*|" + splitter + "*$";
        System.out.println(regex);
        return srcStr.replaceAll(regex, "");
    }
    public MovieAnalyzer(String dataset_path) {
//        List<Movie> Movielist = null;
        int i=0;int j=0;
        try  {
            //(BufferedReader br = Files.newBufferedReader(Paths.get(dataset_path)))
            InputStreamReader isr = new InputStreamReader(new FileInputStream(dataset_path), "UTF-8");
            BufferedReader br = new BufferedReader(isr);
            String line;
            Movielist = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                String[] columns = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)",-1);
                i++;
//                String mid=String.join("|", columns);
//                System.out.println(String.join("|", columns));
//                String[] New=mid.split("\\|");

                Movie x = new Movie();
 //               if (columns.length == 16) {
//                    System.out.println(New[15]);
                    x.setPoster_Link(columns[0]);
                    x.setSeries_Title(columns[1]);
                    if (columns[2] != null && columns[2].matches("-?\\d+(\\.\\d+)?")) {
                        x.setReleased_Year(Integer.parseInt(columns[2]));
//                        j++;
//                        System.out.println(j);
                    }
                    x.setCertificate(columns[3]);
                    x.setRuntime(columns[4]);
                    x.setGenre(columns[5]);
                    if (columns[6] != null && columns[6].matches("-?\\d+(\\.\\d+)?")) {
                        x.setIMDB_Rating((float) Double.parseDouble(columns[6]));
                    }
                    x.setOverview(columns[7].replaceAll("^\"*|\"*$",""));
                    if (columns[8] != null && columns[8].matches("-?\\d+(\\.\\d+)?")) {
                        x.setMeta_score(Integer.parseInt(columns[8]));

                    }
                    x.setDirector(columns[9]);
                    x.setStar1(columns[10]);
                    x.setStar2(columns[11]);
                    x.setStar3(columns[12]);
                    x.setStar4(columns[13]);
                    if (columns[14] != null && columns[14].matches("-?\\d+(\\.\\d+)?")) {
                        x.setNo_of_Votes(Integer.parseInt(columns[14]));
                    } else {
                        continue;
                    }
                    if (columns[15].replace(",", "").matches("-?\\d+(\\.\\d+)?")) {
                        x.setGross(Integer.parseInt(columns[15].replace(",", "")));
                    }
                    Movielist.add(x);


//                }
//                System.out.println(columns[8]);

            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        AllMovie=Movielist.stream();
//        System.out.println(AllMovie);
//        System.out.println(Movielist.size());
//        System.out.println(i);
    }


    public Map<Integer, Integer> getMovieCountByYear(){
        Map<Integer, Integer> list1=new HashMap<>();
        Map<Integer,Long> yearCount=AllMovie.collect(Collectors.groupingBy(Movie::getReleased_Year, Collectors.counting()));
        Map.Entry<Integer, Integer> entry = null;
        for(Integer m:yearCount.keySet()){
            list1.put(m,Integer.parseInt(yearCount.get(m).toString()));
//            System.out.println(m+" == "+yearCount.get(m));
//            System.out.println(m+" == "+list1.get(m));
        }
            ListIterator<Map.Entry<Integer, Integer>> li = new ArrayList<Map.Entry<Integer, Integer>>(list1.entrySet()).listIterator(list1.size());
            while(li.hasPrevious()) {
                 entry = li.previous();
//                System.out.println(entry.getKey()+" == "+entry.getValue());
                list1.put(entry.getKey(),entry.getValue());

        }

        return list1;
    }

    public Map<String, Integer> getMovieCountByGenre(){
        int d = 0,c= 0,ac= 0,ad= 0,b= 0,hi= 0,t= 0,m= 0,an= 0,f= 0,ho= 0,w= 0,fa= 0,sf=0,co=0,we=0,sp=0,fn=0,r=0,my=0,ml=0;
        int[] xy={d,c,ac,ad,b,hi,t,m,an,f,ho,w,fa,sf,co,we,sp,fn,r,my,ml};int mid=0;
        Map<String, Integer> map2 = new TreeMap<String, Integer>(
                new Comparator<String>() {
                    public int compare(String obj1, String obj2) {
                        return obj1.compareTo(obj2);
                    }
                });
        Map<String, Integer> list2=new HashMap<>();
        Map.Entry<String, Integer> entry = null;
//        Map<String,Integer> map2=new LinkedHashMap<String,Integer>();
//        Map<String,Long> yearCount=AllMovie.collect(Collectors.groupingBy(Movie::getGenre, Collectors.counting()));
        List<String> listGenre=AllMovie.map(Movie::getGenre).collect(Collectors.toList());
        for(String s:listGenre){
            if(s.contains("Drama")){d++;}if(s.contains("Sci-Fi")){sf++;}
            if(s.contains("Crime")){c++;}if(s.contains("Animation")){an++;}
            if(s.contains("Action")){ac++;}if(s.contains("War")){w++;}
            if(s.contains("Adventure")){ad++;}if(s.contains("Comedy")){co++;}
            if(s.contains("Family")){f++;}if(s.contains("Western")){we++;}
            if(s.contains("Fantasy")){fa++;}if(s.contains("Horror")){ho++;}
            if(s.contains("Thriller")){t++;}if(s.contains("History")){hi++;}
            if(s.contains("Music")){m++;}if(s.contains("Sport")){sp++;}
            if(s.contains("Biography")){b++;}if(s.contains("Film-Noir")){fn++;}
            if(s.contains("Romance")){r++;}if(s.contains("Mystery")){my++;}if(s.contains("Musical")){ml++;}
        }

        list2.put("Drama",d);list2.put("Crime",c);list2.put("Action",ac);list2.put("Adventure",ad);list2.put("Family",f);
        list2.put("Fantasy",fa);list2.put("Thriller",t);list2.put("Music",m);list2.put("Biography",b);list2.put("Romance",r);
        list2.put("Sci-Fi",sf);list2.put("Animation",an);list2.put("War",w);list2.put("Comedy",co);list2.put("Western",we);
        list2.put("Horror",ho);list2.put("History",hi);list2.put("Sport",sp);list2.put("Film-Noir",fn);list2.put("Mystery",my);list2.put("Musical",ml);
//        System.out.println(list2);
        list2.entrySet().stream()
                .sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
                .forEachOrdered(e -> map2.put(e.getKey(), e.getValue()));
//        System.out.println(list2);
//        System.out.println(map2);
//        Map<String, Integer> m1 = map2.entrySet().stream()
//                .sorted((e1, e2) -> Integer.compare(e1.getValue(), e2.getValue()))
//                .collect(Collectors.toMap(Map.Entry::getKey,
//                        Map.Entry::getValue,(e1, e2) -> e1,
//                        LinkedHashMap::new));


        //        System.out.println(sortOtherMap);

//        ListIterator<Map.Entry<String, Integer>> li = new ArrayList<Map.Entry<String, Integer>>(list2.entrySet()).listIterator(list2.size());
//        while(li.hasPrevious()) {
//            entry = li.previous();
//                System.out.println(entry.getKey()+" == "+entry.getValue());
//            list2.put(entry.getKey(),entry.getValue());
//
//        }

        return map2.entrySet().stream()
                .sorted((e1, e2) -> Integer.compare( map2.get(e2.getKey()),map2.get(e1.getKey())))
                .collect(Collectors.toMap(Map.Entry::getKey,
                        Map.Entry::getValue,
                        (e1, e2) -> e1,
                        LinkedHashMap::new));
    }

    public Map<List<String>, Integer> getCoStarCount(){
        Map<List<String>, Integer> map3=new HashMap<>();
        for(int b=0;b<Movielist.size();b++){
            List<List<String>> l=new LinkedList<>() {};

            List<String> s= new ArrayList<>();s.add(Movielist.get(b).getStar1());s.add(Movielist.get(b).getStar2());
            l.add(s.stream().sorted().collect(Collectors.toList()));
            List<String> sa= new ArrayList<>();sa.add(Movielist.get(b).getStar1());sa.add(Movielist.get(b).getStar3());
            l.add(sa.stream().sorted().collect(Collectors.toList()));
            List<String> sd= new ArrayList<>();sd.add(Movielist.get(b).getStar1());sd.add(Movielist.get(b).getStar4());
            l.add(sd.stream().sorted().collect(Collectors.toList()));
            List<String> sf= new ArrayList<>();sf.add(Movielist.get(b).getStar2());sf.add(Movielist.get(b).getStar3());
            l.add(sf.stream().sorted().collect(Collectors.toList()));
            List<String> sg= new ArrayList<>();sg.add(Movielist.get(b).getStar2());sg.add(Movielist.get(b).getStar4());
            l.add(sg.stream().sorted().collect(Collectors.toList()));
            List<String> sq= new ArrayList<>();sq.add(Movielist.get(b).getStar3());sq.add(Movielist.get(b).getStar4());
            l.add(sq.stream().sorted().collect(Collectors.toList()));

//            l.add(new LinkedList<>(Arrays.asList(Movielist.get(b).getStar3(),Movielist.get(b).getStar2())));l.add(new LinkedList<>(Arrays.asList(Movielist.get(b).getStar4(),Movielist.get(b).getStar2())));l.add(new LinkedList<>(Arrays.asList(Movielist.get(b).getStar4(),Movielist.get(b).getStar3())));

            outer:for(int i=0;i<6;i++){
                int x=1;
                Set<List<String>> set=map3.keySet();
                for(List<String> sset:set){
                    if(sset.equals(l.get(i))){
                        break outer;
                    }
                }

            for(int a=1+b;a<Movielist.size();a++){
                List<List<String>> ll=new LinkedList<>();
                List<String> n= new ArrayList<>();n.add(Movielist.get(a).getStar1());n.add(Movielist.get(a).getStar2());
                ll.add(n.stream().sorted().collect(Collectors.toList()));
//               ll.add(new LinkedList<>(Arrays.asList(Movielist.get(a).getStar3(),Movielist.get(a).getStar2())));ll.add(new LinkedList<>(Arrays.asList(Movielist.get(a).getStar4(),Movielist.get(a).getStar3())));ll.add(new LinkedList<>(Arrays.asList(Movielist.get(a).getStar3(),Movielist.get(a).getStar2())));
                List<String> nn= new ArrayList<>();nn.add(Movielist.get(a).getStar1());nn.add(Movielist.get(a).getStar3());
                ll.add(nn.stream().sorted().collect(Collectors.toList()));
                List<String> nv= new ArrayList<>();nv.add(Movielist.get(a).getStar1());nv.add(Movielist.get(a).getStar4());
                ll.add(nv.stream().sorted().collect(Collectors.toList()));
                List<String> nz= new ArrayList<>();nz.add(Movielist.get(a).getStar2());nz.add(Movielist.get(a).getStar3());
                ll.add(nz.stream().sorted().collect(Collectors.toList()));
                List<String> nx= new ArrayList<>();nx.add(Movielist.get(a).getStar2());nx.add(Movielist.get(a).getStar4());
                ll.add(nx.stream().sorted().collect(Collectors.toList()));
                List<String> nc= new ArrayList<>();nc.add(Movielist.get(a).getStar3());nc.add(Movielist.get(a).getStar4());
                ll.add(nc.stream().sorted().collect(Collectors.toList()));

                    for(int k=0;k<6;k++){
                        if (l.get(i).equals(ll.get(k))) {
                            x++;
                        }
                    }
                }     map3.put(l.get(i),x);
              }
            }
        Map<List<String>, Integer> m1 = new TreeMap<>();
                map3.entrySet().stream()
                        .sorted((p1, p2) -> p2.getValue().compareTo(p1.getValue())).toList().forEach(e -> m1.put(e.getKey(), e.getValue()));

//        System.out.println(m1);
        return m1;
    }

    public List<String> getTopMovies(int top_k, String by){
        List<String> map4=new ArrayList<>();

        if(by.equals("runtime")){
            List<Movie> list4 = new ArrayList<>();
//            list44 = AllMovie.sorted(Comparator.comparing(Movie::getSeries_Title,
//                    Comparator.reverseOrder())).collect(Collectors.toList());
            AllMovie.forEach(p -> {
                list4.add(new Movie(p.getSeries_Title(),p.getRuntime(),p.getOverview()));
                });
            list4.sort(Comparator.comparing(Movie::getSeries_Title));
            list4.sort((o1, o2) -> Integer.parseInt(o2.getRuntime().substring(0,o2.getRuntime().length()-4))-Integer.parseInt(o1.getRuntime().substring(0,o1.getRuntime().length()-4)));
            for(Movie movies:list4){
                map4.add(movies.getSeries_Title());
            }
//            System.out.println(map4.subList(0,top_k));
        }

        if(by.equals("overview")){
            List<Movie> list44 = new ArrayList<>();
//            list44 = AllMovie.sorted(Comparator.comparing(Movie::getSeries_Title,
//                    Comparator.reverseOrder())).collect(Collectors.toList());
            AllMovie.forEach(p -> {
                list44.add(new Movie(p.getSeries_Title(),p.getRuntime(),p.getOverview()));
            });
            list44.sort(Comparator.comparing(Movie::getSeries_Title));
            list44.sort((o1, o2) -> (o2.getOverview().length()-o1.getOverview().length()));
            for(Movie movies:list44){
                map4.add(movies.getSeries_Title());
            }
            System.out.println(map4.subList(0,top_k));
        }
        return map4.subList(0,top_k);
    }

    public List<String> getTopStars(int top_k, String by){
        List<String> list5=new ArrayList<>();
        Map<String,Double> map5=new HashMap<>();
        if(by.equals("rating")){
            Set<String> set=new HashSet<String>();
            for(Movie m:Movielist){
                set.add(m.getStar1());set.add(m.getStar3());
                set.add(m.getStar2());set.add(m.getStar4());
            }
            for(String s:set){
                float ff=0; int n=0; double avg=0;
                for(int i=0;i< Movielist.size();i++){
                    if(s.equals(Movielist.get(i).getStar1())){
                        ff+=Movielist.get(i).getIMDB_Rating();
                        n++;
                    }
                    if(s.equals(Movielist.get(i).getStar2())){
                        ff+=Movielist.get(i).getIMDB_Rating();
                        n++;
                    }
                    if(s.equals(Movielist.get(i).getStar3())){
                        ff+=Movielist.get(i).getIMDB_Rating();
                        n++;
                    }
                    if(s.equals(Movielist.get(i).getStar4())){
                        ff+=Movielist.get(i).getIMDB_Rating();
                        n++;
                    }
                }
                avg=ff/n;
                map5.put(s,avg);

            }
            Map<String,Double> m5=new HashMap<>();
            map5.entrySet()
                    .stream()
                    .sorted((p1, p2) -> p2.getValue()
                            .compareTo(p1.getValue())).toList()
                    .forEach(e -> m5.put(e.getKey(), e.getValue()));

            System.out.println(m5);
            list5=new ArrayList<String>(m5.keySet());
            System.out.println(list5.subList(0,top_k));
        }


        return list5;
    }

    public static void main(String[] args) {
//        MovieAnalyzer M=new MovieAnalyzer("C:/Users/Evan玖/Desktop/java/A1_Sample/src/imdb_top_500 - 2.csv");
        MovieAnalyzer M=new MovieAnalyzer("C:/Users/Evan玖/Desktop/java/A1_Sample/src/imdb_top_500.csv");
 //       M.getCoStarCount();
 //       M.getMovieCountByGenre();
 //       M.getTopMovies(20,"overview");
        M.getTopStars(10,"rating");


    }
    }